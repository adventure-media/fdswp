<?php
include(plugin_dir_path(__FILE__)."init_file.php");
class sasoEventtickets_TicketDesigner {

    public function getTicketTemplate() {
        $html = '';
        return $html;
    }
}
?>